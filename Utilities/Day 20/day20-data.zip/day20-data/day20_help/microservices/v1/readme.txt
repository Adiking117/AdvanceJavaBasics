2 Microservices 
Restaurant Service n Restaurant Menu Service
RestTemplate based synchronous communication between MS