package com.cdac.dependent;

public interface School {
	void manageAcademics();
	void organizeSportsEvent();
}
